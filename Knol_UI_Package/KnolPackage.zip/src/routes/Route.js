// Route.js
import React, { useState } from "react";
import { Navigate, Routes, Route, useLocation } from "react-router-dom";
import MiniDrawer from "../components/MiniDrawer";
import { useAuth } from "../Auth/AuthContext";
import Login from "../components/Login";

// Private Route Component
const PrivateRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  if (loading) return null;
  return isAuthenticated ? children : <Navigate to="/login" replace />;
};

const AppRoutes = (props) => {
  const { isAuthenticated, loading } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const location = useLocation();
  const isLoginPage = location.pathname === "/login";
  const { token, projectId, customerId } = props;
  if (loading) return null;
  return (
    <div>
      <Routes>
         {/* <Route path="/login" element={<Login />} />  */}
         <Route
          path="/"
          element={
              <MiniDrawer 
              projectId={projectId}
              customerId={customerId}/>
          } 
        />
        <Route
          path="/dashboard" 
          element={
            <PrivateRoute>
              <MiniDrawer 
           projectId={projectId}
           customerId={customerId}/>
            </PrivateRoute>
          }
        />
        <Route
          path="*" 
          element={<Navigate to={ "/dashboard"} />}
        /> 
      </Routes>
    </div>
  );
};

export default AppRoutes;
