import { List } from "devextreme-react/list";
import React, { useState, useEffect } from "react";
import ArticleDetails from "../components/ArticleDetails";
import MainContent from "../components/MainContent";
import logo from "../assets/logo.png";
import { SelectBox } from "devextreme-react/select-box";
import "../App.css";
import axios from "axios";
import { jwtDecode } from "jwt-decode";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../Auth/AuthContext";
import Tooltip from "devextreme-react/tooltip";
import { Button } from "devextreme-react/button";
import { Tabs } from "devextreme-react/tabs";


const settings = ["Profile", "Account", "Dashboard", "Logout"];

export default function MiniDrawer({ customerId, projectId }) {
  const [selectedTab, setSelectedTab] = React.useState(0);
  const [isChatOpen, setIsChatOpen] = React.useState(false);
  const [listResponse, setListResponse] = useState([]);
  const [isMainContentVisible, setIsMainContentVisible] = useState(true);
  const [isArrowBack, setIsArrowBack] = useState(true);
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [open, setOpen] = React.useState(false);
  const [selectedArticle, setSelectedArticle] = React.useState({
    groupId: null,
    postTypeId: null,
    ConversationId: "",
    actionId: 0,
    title: "",
    InboxItemId: 0,
    InboxItemTypeId: 0,
  });
  const [menuVisible, setMenuVisible] = useState(false);

  const navigate = useNavigate();
  const { logout } = useAuth();

  useEffect(() => {
    if (selectedGroup?.ArticleInfo?.length > 0 && !selectedTab) {
      const defaultTab = selectedGroup.ArticleInfo[0];
      setSelectedTab(defaultTab.PostTypeId);

      setSelectedArticle((prev) => ({
        ...prev,
        postTypeId: defaultTab.PostTypeId,
        ConversationId: defaultTab.ConversationId || prev.ConversationId,
        title: defaultTab.PostTypeName || prev.title,
        InboxItemId: 0,
        actionId: 0,
        InboxItemTypeId: 0,
      }));
    }
  }, [selectedGroup, selectedTab, setSelectedTab, setSelectedArticle]);

  const handleTabChange = ({ itemData }) => {
    const newValue = itemData.PostTypeId;

    setIsMainContentVisible(true);
    setIsArrowBack(true);
    setSelectedTab(newValue);

    const selectedArticleDetails = selectedGroup?.ArticleInfo?.find(
      (article) => article.PostTypeId === newValue
    );

    setSelectedArticle((prev) => ({
      ...prev,
      postTypeId: newValue,
      ConversationId:
        selectedArticleDetails?.ConversationId || prev.ConversationId,
      title: selectedArticleDetails?.PostTypeName || prev.title,
      InboxItemId: 0,
      actionId: 0,
      InboxItemTypeId: 0,
    }));
  };

  const tabItems =
    selectedGroup?.ArticleInfo?.map((article) => ({
      PostTypeId: article.PostTypeId,
      text: `${article.PostTypeName} (${article.DocumentCreatedCount})`,
    })) || [];



  const handleOpenUserMenu = () => {
    setMenuVisible((prev) => !prev); // Toggle menu visibility
  };

  const handleCloseUserMenu = (setting) => {
    setMenuVisible(false);

    if (setting) {
      switch (setting) {
        case "Profile":
          break;
        case "Account":
          break;
        case "Dashboard":
          break;
        case "Logout":
          logout();
          navigate("/login");
          break;
        default:
          break;
      }
    }
  };

  const toggleMainContent = () => {
    setIsMainContentVisible(!isMainContentVisible);
    setIsArrowBack(!isArrowBack);
  };

  // Handler to update state based on dropdown selection
  const handleGroupChange = (event) => {
    const groupId = event.value;
    setSelectedGroupId(groupId);

    const group = listResponse.find((group) => group.GroupId === groupId);
    setSelectedGroup(group);

    const initialPostTypeId = group?.ArticleInfo?.[0]?.PostTypeId || null;

    setSelectedTab(initialPostTypeId);
    setSelectedArticle({
      groupId,
      postTypeId: initialPostTypeId,
      ConversationId: group?.ConversationId || "",
      actionId: 0,
      title: "",
      InboxItemId: 0,
      InboxItemTypeId: 0,
    });
  };

  // const handleTabChange = (event, newValue) => {
  //   setIsMainContentVisible(true);
  //   setIsArrowBack(true);
  //   setSelectedTab(newValue);

  //   const selectedArticleDetails = selectedGroup?.ArticleInfo?.find(
  //     (article) => article.PostTypeId === newValue
  //   );

  //   setSelectedArticle((prev) => ({
  //     ...prev,
  //     postTypeId: newValue,
  //     ConversationId:
  //       selectedArticleDetails?.ConversationId || prev.ConversationId,
  //     title: selectedArticleDetails?.PostTypeName || prev.title,
  //     InboxItemId: 0,
  //     actionId: 0,
  //     InboxItemTypeId: 0,
  //   }));
  // };

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
  };

  const fetchData = async () => {
    console.log("kjfhvfkd")
    try {
      // const token = sessionStorage.getItem("authToken");
      // if (!token) throw new Error("Authorization token is missing");
      // const decodedToken = jwtDecode(token);
      // const UserId = decodedToken?.UserId;
      const response = await axios.post(
        "https://knolapi.accesshealthcare.co/api/ArticleDashboard/GetUserInboxGroupInfoByClient",
        {
          LoggedUserId: "20",
          params: {},
        }
      );

      let resData = response.data.Data;
      console.log("gmmm", resData)
      if (resData?.Groups && resData.Groups.length > 0) {
        const targetCustomerId = customerId; // Replace with your desired CustomerId
        const targetProjectId = projectId; // Replace with your desired ProjectId

        // Filter the group based on CustomerId and ProjectId
        const filteredGroup = resData.Groups.find(
          (group) =>
            group.CustomerId === targetCustomerId && group.ProjectId === targetProjectId
        );
        console.log("customerId, projectId}", projectId, filteredGroup)

        // If no match, default to the first group
        const defaultGroup = filteredGroup || resData.Groups[0];
        const defaultPostTypeId =
          defaultGroup?.ArticleInfo?.[0]?.PostTypeId || null;

        setSelectedGroupId(defaultGroup.GroupId);
        setSelectedGroup(defaultGroup);
        setSelectedTab(defaultPostTypeId);

        setSelectedArticle({
          groupId: defaultGroup.GroupId,
          postTypeId: defaultPostTypeId,
          ConversationId: defaultGroup?.ConversationId || "",
          actionId: 0,
          title: "",
          InboxItemId: 0,
          InboxItemTypeId: 0,
        });
      }

      setListResponse(resData?.Groups);
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div style={{ background: "#F0F0F0" }}>
      {/* <div
        position="fixed"
        open={open}
        color="transparent"
        style={{ boxShadow: "none" }}
      >
        <div
          style={{ background: "#F0F0F0", borderBottom: "1px solid #DCD8D8" }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              padding: "15px",
              justifyContent: "space-between",
              flexGrow: 1,
            }}
          >
            <img
              src={logo}
              alt="Logo"
              style={{ width: "100px" }}
              className="h-auto"
            />
            <div
              style={{
                display: "flex",
                justifyContent: "flex-end",
                alignItems: "center",
                width: "100%",
                gap: "10px",
              }}
            >
              <h2 style={{ marginRight: "1px", whiteSpace: "nowrap" }}>
                Current workspace:
              </h2>
              <div style={{ minWidth: 200 }}>
                <SelectBox
                  dataSource={listResponse}
                  value={selectedGroupId}
                  onValueChanged={handleGroupChange}
                  displayExpr="GroupName"
                  valueExpr="GroupId"
                  placeholder="Select Group"
                  width="100%"
                  height="32px"
                  elementAttr={{
                    style: {
                      backgroundColor: "white",
                      border: "1px solid #e0e0e0",
                      borderRadius: "5px",
                    },
                  }}
                  dropDownButtonRender={() => (
                    <i
                      style={{
                        color: "#000",
                      }}
                    >
                      ▼
                    </i>
                  )}
                />
              </div>
            </div>
            <div style={{ marginLeft: "24px", display: "flex", alignItems: "center" }}>
              <Tooltip
                showEvent="mouseenter"
                hideEvent="mouseleave"
                contentRender={() => <span>Open settings</span>} // Tooltip content
                position="top"
              />
              <Button
                icon="user"
                onClick={handleOpenUserMenu}
                style={{
                  background: "#F6F6F6",
                  padding: 0,
                  background: "transparent",
                  padding: "0px",
                  border: "transparent",
                  border: "1px solid #000",
                  borderRadius: "20px"
                }}
                size="10px"
              />
              {menuVisible && (
                <div
                  style={{
                    position: "absolute",
                    top: "100px",
                    right: "10px",
                    background: "white",
                    border: "1px solid #e0e0e0",
                    borderRadius: "8px",
                    boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
                    zIndex: 1000,
                    minWidth: "40px",
                  }}
                >
                  <List style={{ width: '130px' }}
                    items={settings}
                    onItemClick={(e) => handleCloseUserMenu(e.itemData)}
                    itemRender={(item) => (
                      <div
                        style={{
                          textAlign: "center",
                          cursor: "pointer",
                        }}
                      >
                        {item}
                      </div>
                    )}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div> */}
      <div
        component="main"
        style={{
          flexGrow: 1,
          padding: "16px",
          paddingBottom: "16px",
          overflow: "auto",
          backgroundColor: "#F0F0F0",
          minHeight: "100vh", // Replicates `min-h-screen`
        }}
        bgcolor="#F0F0F0"
        className="min-h-screen"
      >
        <div
          align="center"
          justify="space-between"
          style={{ margin: "8px 0" }}
        >
          <Tabs
            style={{ textAlign: "left" }}
            className="knoltab-slection"
            dataSource={tabItems}
            selectedIndex={tabItems.findIndex((tab) => tab.PostTypeId === selectedTab)}
            onItemClick={handleTabChange}
            itemRender={(item) => (
              <div className="category-tab"
                style={{
                  fontSize: "13px",
                  padding: "0 10px",
                  minWidth: "40px",
                  minHeight: "25px",
                  color: item.PostTypeId === selectedTab ? "#ffffff" : "black",
                  backgroundColor:
                    item.PostTypeId === selectedTab ? "#121559" : "transparent",
                  margin: "0 10px 0 0",
                  textTransform: "capitalize",
                  fontWeight: "bold",
                  border: "1px solid #113E70",
                  borderRadius: "3px",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  cursor: "pointer",
                }}
              >
                {item.text}
              </div>
            )}
          />
        </div>
        <div
          className="flex flex-col md:flex-row gap-5"
          style={{ height: "90vh", display: "flex" }}
        >
          {isMainContentVisible && (
            <div
              className="w-full md:w-1/4 bg-white rounded-lg left_art"
              style={{
                height: "calc(90vh - 50px)",
                overflowY: "auto",
              }}
            >
              <MainContent
                selectedArticle={selectedArticle}
                onSelectArticle={setSelectedArticle}
              />
            </div>
          )}

          <div
            className="flex-1 bg-white rounded-lg right_art"
            style={{
              height: "calc(90vh - 50px)",
              overflowY: "auto",
            }}
          >
            <ArticleDetails
              selectedArticle={selectedArticle}
              toggleMainContent={toggleMainContent}
              isArrowBack={isArrowBack}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
