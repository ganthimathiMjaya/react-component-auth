import React, { useEffect, useState } from "react";
import { AiOutlineLike, AiFillLike } from 'react-icons/ai';
import { Button } from "devextreme-react/button";
import { VscEye } from "react-icons/vsc";
import { MdRemoveRedEye } from "react-icons/md";
import axios from 'axios';
import loader from '../assets/loader.svg';
import 'devextreme/dist/css/dx.light.css';
import { AiFillStar, AiOutlineStar } from 'react-icons/ai';



const ArticleDetails = ({ selectedArticle, toggleMainContent, isArrowBack }) => {
  const { groupId, postTypeId, actionId, ConversationId, InboxItemId, InboxItemTypeId, title } = selectedArticle || {};
  const [pdfUrl, setPdfUrl] = useState(null);
  const [articleListResponse, setArticleListResponse] = useState([]);
  const handleActionClick = async (action) => {
    try {
      await axios.post('https://knolapi.accesshealthcare.co/api/Article/SubmitUserAction', {
        params: {
          PostId: InboxItemId,
          UserId: 1,
          Action: action
        }
      });

      // Update UI based on the action
      if (action === 'Liked') {
        fetchData();
      } else if (action === 'Favorite') {
        fetchData();
      }

    } catch (error) {
      console.error("Error submitting user action: ", error);
    }
  };

  const checkAndCallApi = async (attachments) => {
    const targetIdentifier = "6faa083c-0d34-4e55-86ce-9b421371f07c"; // Your target identifier

    attachments.forEach((attachment) => {
      if (attachment.AttachmentIdentifier === targetIdentifier) {
        const fileCaption = attachment.FileCaption;
        const fileType = fileCaption.split('.').pop().toLowerCase();;
        let mimeType;
        let viewerUrl;

        switch (fileType) {
          case 'pdf':
            mimeType = 'application/pdf';
            break;
          case 'doc':
          case 'docx':
            // For .doc or .docx, use either Google Docs Viewer or Office Viewer
            viewerUrl = `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent('YOUR_FILE_URL')}`;
            break;
          case 'xlsx':
            mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
            break;
          default:
            mimeType = 'application/octet-stream';
        }

        let data = JSON.stringify({
          "AttachmentIdentifier": attachment.AttachmentIdentifier,
          "FileCaption": attachment.FileCaption,
          "FileId": attachment.FileId,
          "FileByte": attachment.FileByte,
          "AllowedFileCount": attachment.AllowedFileCount,
          "Remarks": attachment.Remarks
        });

        let config = {
          method: 'post',
          maxBodyLength: Infinity,
          url:  'https://knolapi.accesshealthcare.co/api/File/GetFiles',
          headers: {
            'Content-Type': 'application/json'
          },
          data: data,
          responseType: 'blob'
        };

        axios.request(config)
          .then((response) => {

            const blob = new Blob([response.data], { type: mimeType });

            if (fileType === 'doc' || fileType === 'docx') {
              viewerUrl = `https://www.mass.gov/doc/andys-test-for-url-issue-0/download`;
              // viewerUrl = `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(URL.createObjectURL(blob))}`;
              setPdfUrl(viewerUrl);
            } else {
              const blobURL = URL.createObjectURL(blob);
              setPdfUrl(blobURL);
            }

          })
          .catch((error) => {
            console.error('Error making API call:', error);
          });
      }
    });
  };

  const fetchData = async () => {
    try {
      const response = await axios.post('https://knolapi.accesshealthcare.co/api/ArticleDashboard/GetInboxItemDetails',
        {
          LoggedUserId: 1,
          params: {
            InboxItemId: InboxItemId,
            InboxItemTypeId: InboxItemTypeId
          }
        }
      );
      let resData = response.data.Data;
      checkAndCallApi(resData.Attachments);
      setArticleListResponse(resData);
    } catch (error) {
      console.error('Error making API call:', error);
    }
  };

  useEffect(() => {
    fetchData();
  }, [selectedArticle]);

  const {
    HeaderTitle,
    PublishDate,
    DocTitle,
    PublishTime,
    DocContent,
    LikeCount,
    ViewCount,
    IsFav,
    isLiked,
    isViewed
  } = articleListResponse || {};
  return (
    <div
      direction="row"
      width="100%"
      className="w-full border border-slate-200"
      style={{
        maxWidth: "100%",
      }}
    >
      {selectedArticle?.groupId && selectedArticle?.postTypeId && selectedArticle?.InboxItemId && selectedArticle?.InboxItemTypeId ? (
        <>
          <div
            justifyContent="space-between"
            alignItems="flex-start"
            style={{
              justifyContent: "space-between",
              display: "flex",
              padding: "15px 10px 28px 10px" ,
              width: "100%",
              gap: "10px",
              borderBottom: "1px solid #DBDBDB",
            }}
          >
            <div style={{ display: 'flex' }} display="flex" alignItems="baseline" width="100%" gap={1}>
              {isArrowBack ?

                <Button style={{ padding: 0, marginTop: 2, border: 'none' }} onClick={toggleMainContent} icon="arrowleft" />
                : <Button style={{ padding: 0, marginTop: 2, border: 'none' }} onClick={toggleMainContent} icon="arrowright" />
              }
              <div style={{ marginLeft: '8px', width: '100%' }}>
                <div
                  style={{
                    fontSize: window.innerWidth < 600 ? '14px' : '16px', // Responsive font size
                    fontWeight: 'bold',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  }}
                >
                  {HeaderTitle || 'No Title Available'}
                </div>
                <div
                  style={{
                    fontSize: window.innerWidth < 600 ? '10px' : '12px', // Responsive font size
                    color: '#666', // Matches `textSecondary` color
                  }}
                >
                  {PublishDate}
                </div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '10px' }}>
              <div style={{ textAlign: "center" }}>
                <div
                  style={{ cursor: 'pointer', display: 'flex', justifyContent: 'center' }}
                  onClick={() => handleActionClick('Liked')}
                >
                  {isLiked ? <AiFillLike size={20} /> : <AiOutlineLike size={20} />}
                </div>
                <span style={{ fontSize: "12px" }}>{LikeCount}</span>
              </div>
              <div style={{ textAlign: "center" }}>
                <div
                  style={{ cursor: 'pointer', display: 'flex', justifyContent: 'center' }}
                >
                  {isViewed ? <MdRemoveRedEye fontSize="20px" /> : <VscEye fontSize="20x" />}
                </div>
                <span style={{ fontSize: "12px" }}>{ViewCount}</span>
              </div>
              <div style={{ textAlign: "center" }}>
                <div
                  style={{ cursor: 'pointer', display: 'flex', justifyContent: 'center' }}
                  onClick={() => handleActionClick('Favorite')}
                >
                  {IsFav ? <AiFillStar fontSize="20px" /> : <AiOutlineStar fontSize="20x" />}
                </div>
                <span style={{ fontSize: "12px" }}>Favorite</span>
              </div>
            </div>
          </div>

          <div direction="row"
            style={{
              padding: "16px", // Corresponds to xs: 2 (2 * 8px)
            }}>
            <div>
              <div
                style={{
                  fontSize: '14px', 
                  fontWeight: 'bold', 
                  marginBottom: '8px', // Corresponds to `mb={1}` (1 * 8px)
                }}
              >
                {DocTitle || 'No Document Title Available'}
              </div>
              <div
                style={{
                  fontSize: '16px', 
                  marginBottom: '16px', // Corresponds to `mb={2}` (2 * 8px)
                }}
              >
                {DocContent || 'No content available.'}
              </div>
            </div>

            {DocContent &&
              <div>
                <div style={{
                  height: "100vh", display: "flex", justifyContent: "center",
                }}>
                  {pdfUrl ? (
                    <iframe src={`${pdfUrl}#toolbar=0`} width="1000" height="calc(100vh - 60px)" title="File Preview"></iframe>

                  ) : (
                    <img src={loader} alt="Loading..." style={{
                      display: "block",
                      width: "100px",
                      height: "100px",
                    }} />)}
                </div>


              </div>
            }
          </div>
        </>
      ) : (
        // Show message when no article is selected
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: '80vh',
          }}
        >
          <div
            style={{
              fontSize: '1.25rem', // Equivalent to h6 font size
              color: '#666',       // Equivalent to `textSecondary`
              textAlign: 'center', // Align text
            }}
          >
            Please select an article to view details.
          </div>
        </div>
      )}
    </div>
  );
};

export default ArticleDetails;
