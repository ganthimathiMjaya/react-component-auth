
import { Box } from "devextreme-react/box";
import { TextBox } from "devextreme-react/text-box";
import { Button } from "devextreme-react/button";
import React, { useState, useCallback, useEffect } from "react";
import {
  MdErrorOutline,
  MdNotificationImportant,
  MdOutlineError,
  MdOutlineSort,
  MdSearch,
} from "react-icons/md";
import axios from "axios";
import 'devextreme/dist/css/dx.light.css';
import { TabPanel } from "devextreme-react/tab-panel";
import "../components/MainContent.css";
import { Popup } from "devextreme-react/popup";
import { List } from "devextreme-react/list";
import { ToolbarItem } from 'devextreme-react/popup';

export const MainContent = ({ selectedArticle, onSelectArticle }) => {
  const { groupId = null, postTypeId = null, actionId = null, ConversationId = null, title = "", InboxItemId = null } = selectedArticle || {};
  const [selectedTab, setSelectedTab] = useState(0);
  const [articleListResponse, setArticleListResponse] = useState([]);
  const [hoveredArticle, setHoveredArticle] = useState(null);
  const [clickedArticle, setClickedArticle] = useState(InboxItemId);
  const [searchInput, setSearchInput] = useState('');
  const [sortBy, setSortBy] = useState(null);
  const [anchorEl, setAnchorEl] = useState(null);
  const [popupVisible, setPopupVisible] = useState(false);

  const showPopup = () => {
    setPopupVisible(!popupVisible);
  };

  const open = Boolean(anchorEl);

  const handleSortClick = (event) => {
    console.log(event)

    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const menuItems = [
    { id: "title", text: "Name" },
    { id: "date", text: "Date Created" },
  ];
  const fetchData = async () => {
    try {
      const response = await axios.post('https://knolapi.accesshealthcare.co/api/ArticleDashboard/GetInboxItems',
        {
          LoggedUserId: 1,
          params: {
            GroupId: groupId,
            ActionId: actionId,
            PostTypeId: postTypeId
          }
        }
      );
      let resData = response.data.Data;
      setArticleListResponse(resData);
    } catch (error) {
      console.error('Error making API call:', error);
    }
  };

  useEffect(() => {
    if (groupId) {
      fetchData();
    }
  }, [selectedArticle]);


  const handleTabChange = (selectedIndex) => {
    setSelectedTab(selectedIndex);
    onSelectArticle((prevArticle) => ({
      ...prevArticle,
      InboxItemId: 0,
      InboxItemTypeId: 0,
    }));
  };

  // const handleTabChange = (event, newValue) => {
  //   setSelectedTab(newValue);
  //   onSelectArticle((prevArticle) => ({
  //     ...prevArticle,
  //     InboxItemId: 0,
  //     InboxItemTypeId: 0,
  //   }));
  // };

  const handleMouseEnter = (articleId) => {
    setHoveredArticle(articleId);
  };

  const handleMouseLeave = () => {
    setHoveredArticle(null);
  };

  const handleArticleClick = async (article, action) => {
    setClickedArticle(article.Id);
    onSelectArticle({
      groupId: groupId,
      postTypeId: postTypeId,
      actionId: actionId,
      ConversationId,
      title: article.Title,
      InboxItemId: article.Id,
      InboxItemTypeId: article.TypeId,
    });
    try {
      const response = await axios.post('https://knolapi.accesshealthcare.co/api/Article/SubmitUserAction', {
        params: {
          PostId: article.Id,
          UserId: 1,
          Action: action
        }
      });
    } catch (error) {
      console.error("Error submitting user action: ", error);
    }

  };
  const unreadArticles = articleListResponse.filter(article => !article.IsRead && article.Title.toLowerCase().includes(searchInput.toLowerCase()));
  const readArticles = articleListResponse.filter(article => article.IsRead && article.Title.toLowerCase().includes(searchInput.toLowerCase()));
  const favoriteArticles = articleListResponse.filter(article => article.IsFav && article.Title.toLowerCase().includes(searchInput.toLowerCase()));

  const sortArticles = (articles) => {
    return articles.sort((a, b) => {
      if (sortBy === 'title') {
        return a.Title.localeCompare(b.Title);
      } else if (sortBy === 'date') {
        return new Date(b.Createddate) - new Date(a.Createddate);
      }
      return 0;
    });
  };

  const filteredArticles = selectedTab === 0
    ? sortArticles(unreadArticles)
    : selectedTab === 1
      ? sortArticles(readArticles)
      : sortArticles(favoriteArticles);

  const getIconForType = (type) => {
    switch (type) {
      case "PWI":
        return <MdOutlineError color="red" size={20} />;
      case "Notification":
        return <MdNotificationImportant color="blue" size={20} />;
      default:
        return <MdErrorOutline color="gray" size={20} />;
    }
  };

  const shouldShowTypeText = (type) => {
    const typesWithText = ["PWI", "Update"];
    return typesWithText.includes(type);
  };

  const tabs = [
    { id: 0, title: `Unread (${unreadArticles.length})` },
    { id: 1, title: `Read (${readArticles.length})` },
    { id: 2, title: "Favorites" },
  ];
  console.log("anchorEl", open)

  return (
    <div
      style={{
        minWidth: 300,
        boxShadow: "-5px 0 10px rgba(0, 0, 0, 0.1)",
        zIndex: 1,
      }}
    >
      <div style={{ padding: "8px 16px" }}>
        <TabPanel
          dataSource={tabs}
          selectedIndex={selectedTab}
          onSelectionChanged={(e) => handleTabChange(e.component.option("selectedIndex"))}
          showNavButtons={true}
          loop={true}
          animationEnabled={true}
          focusStateEnabled={false}
        />
      </div>
      <div style={{
        padding: "16px", height: "auto",
        marginBottom: "16px", display: "flex", width: "100%"
      }} >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap:'10px',
            height: "35px",
            flex: 1,
            padding: "0px",
            marginRight:'10px'
          }}
        >
          <TextBox
            value={searchInput}
            onValueChanged={(e) => setSearchInput(e.value)}
            placeholder="Search"
            stylingMode="outlined"
            showClearButton={true}
            style={{ flex: 1, height: "100%",position:'relative' }}
          >
          <Button
            icon="search"
            onClick={() => console.log("Search triggered:", searchInput)}
            width="25px"
            height="100%"
            style={{
              display: "flex",
              justifyContent: "center",
              border:'none',
              alignItems: "center",
              position:'absolute',
              right:'10px'
            }}
          >
            <MdSearch size={17} color="black" />
          </Button>
          </TextBox>

        </div>

        <div className="button-container sortingsubpanel">
          <Button
            icon="filter"
            style={{
              background: "#F6F6F6",
              padding: 0,
            }}
            size="10px"
            onClick={showPopup}
          />
          {popupVisible && 
           <div className="sortingpopup">
                <ul>
                <List
            items={menuItems}
            selectionMode="none"
            onItemClick={(e) => {
              setSortBy(e.itemData.id);
              handleClose();
            }}
            itemRender={(item) => (
              <div style={{  cursor: "pointer" }}>{item.text}</div>
            )}
          />
                  
                </ul>
              </div>
}
        </div>

             

      </div>

      {/* <Popup
        width={360}
        height={320}
        showTitle={false}
        shading={false}
        visible={popupVisible}
        onHiding={hide}
        hideOnOutsideClick={true}
      >
          <List
            items={menuItems}
            selectionMode="none"
            onItemClick={(e) => {
              setSortBy(e.itemData.id);
              handleClose();
            }}
            itemRender={(item) => (
              <div style={{ padding: "10px", cursor: "pointer" }}>{item.text}</div>
            )}
          />
      </Popup> */}
      {/* <Popup
        visible={open}
        onHiding={handleClose}
        closeOnOutsideClick={true}
        dragEnabled={false}
        showCloseButton={false}
        width={200}
        height="auto"
        position={{
          at: "bottom left",
          my: "top left",
          of: anchorEl, // Position relative to the anchor element
        }}
      >
        <List
          items={menuItems}
          selectionMode="none"
          onItemClick={(e) => {
            setSortBy(e.itemData.id);
            handleClose();
          }}
          itemRender={(item) => (
            <div style={{ padding: "10px", cursor: "pointer" }}>{item.text}</div>
          )}
        />
      </Popup> */}

      <div style={{ marginTop: "16px" }}>
        {filteredArticles.length > 0 ? (
          filteredArticles.map((article) => (
            <div
              key={article.Id}
              onMouseEnter={() => handleMouseEnter(article.Id)}
              onMouseLeave={handleMouseLeave}
              onClick={() => handleArticleClick(article, "Viewed")}
              className="cursor-pointer"
              style={{
                borderBottom: "1px solid #DBDBDB",
                padding: "10px",
                borderLeft: `4px solid ${clickedArticle === article.Id ? "#121559" : "#113E70"}`,
                backgroundColor: clickedArticle === article.Id ? "#121559" : (hoveredArticle === article.Id ? "#e6f7ff" : "white"),
                color: clickedArticle === article.Id ? "white" : "black", // Optional: Change text color when clicked
                cursor: "pointer",
                transition: "background-color 0.3s ease",
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                {/* Title and Date Section */}
                <div style={{ display: "flex", flexDirection: "column" }}>
                  <h6 style={{ fontWeight: "bold", fontSize: "0.875rem", marginBottom: 0 }}>
                    {article.Title.length > 35 ? `${article.Title.substring(0, 35)}...` : article.Title}
                  </h6>
                  <p style={{ color: "#4B5563", fontSize: "0.875rem", margin: 0 }}>{article.date}</p>
                </div>

                {/* Icon and Type Section */}
                <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                  {getIconForType(article.TypeName)}
                  {shouldShowTypeText(article.TypeName) && (
                    <p style={{ fontSize: "0.75rem", fontWeight: "bold", marginTop: "4px" }}>{article.TypeName}</p>
                  )}
                </div>
              </div>

            </div>
          ))
        ) : (
          <div style={{ marginTop: "16px", textAlign: "center", color: "black" }}>
            No notifications available.
          </div>
        )}
      </div>

    </div>
  );
};

export default MainContent;
